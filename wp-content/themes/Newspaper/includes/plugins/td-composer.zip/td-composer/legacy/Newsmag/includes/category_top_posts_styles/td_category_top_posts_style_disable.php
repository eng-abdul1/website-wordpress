<?php
class td_category_top_posts_style_disable extends td_category_top_posts_style {


    function show_top_posts() {
        ?>

        <?php
    }
}